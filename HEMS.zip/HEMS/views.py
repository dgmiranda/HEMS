# -*- coding: utf-8 -*-

from django.http import JsonResponse
from django.shortcuts import render, HttpResponse
from django.contrib.auth import get_user_model
from django.views.generic import View
import sqlite3
from datetime import datetime

from rest_framework.views import APIView
from rest_framework.response import Response

# Create your views here.
User = get_user_model()

class HomeView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'charts.html', {"customers": 10})

def get_data(request, *args, **kwargs):
    table_name = 'readings'
    id_column = 'uniqueID'
    column_2 = 'reading'
    column_3 = 'time_stamp'

    #Open our database
    db = sqlite3.connect('/Users/dgm/Desktop/HEMS')

    #Get a cursor object
    cursor = db.cursor()


    cursor.execute('select reading, time_stamp from {tn} where {cn} = "cunt"'.\
                        format(tn=table_name, cn=id_column))


    all_cunts = cursor.fetchall()

    values=[]

    dates=[]

    for row in all_cunts:

            values.append(int(row[0]))
            ## unicode to string
            b=str(row[1])
            ##string to datetime
            dates.append(datetime.strptime(b, '%Y-%m-%d %H:%M:%S.%f'))

    db.commit()
    db.close()

    data = {
            "readings": values,
            "date_time": dates,
            }

    return JsonResponse(data)

class ChartData(APIView):

    authentication_classes = []
    permission_classes = []

    def get(self, request, format=None):
            table_name = 'readings'
            id_column = 'uniqueID'
            column_2 = 'reading'
            column_3 = 'time_stamp'

            #Open our database
            db = sqlite3.connect('/Users/dgm/Desktop/HEMS')

            #Get a cursor object
            cursor = db.cursor()


            cursor.execute('select reading, time_stamp from {tn} where {cn} = "cunt"'.\
                                format(tn=table_name, cn=id_column))


            all_cunts = cursor.fetchall()

            values=[]

            dates=[]

            for row in all_cunts:

                    values.append(int(row[0]))
                    ## unicode to string
                    b=str(row[1])
                    ##string to datetime
                    dates.append(datetime.strptime(b, '%Y-%m-%d %H:%M:%S.%f'))

            db.commit()
            db.close()
            qs_count = User.objects.all().count()
            data = {
                "labels": dates,
                "default": values,
            }
            return Response(data)




def home(request):

        table_name = 'readings'
        id_column = 'uniqueID'
        column_2 = 'reading'
        column_3 = 'time_stamp'

        	#Open our database
        db = sqlite3.connect('/Users/dgm/Desktop/HEMS')

        #Get a cursor object
        cursor = db.cursor()


        cursor.execute('select reading, time_stamp from {tn} where {cn} = "cunt"'.\
                            format(tn=table_name, cn=id_column))


        all_cunts = cursor.fetchall()

        values=[]

        dates=[]

        for row in all_cunts:

                values.append(int(row[0]))
                ## unicode to string
                b=str(row[1])
                ##string to datetime
                dates.append(datetime.strptime(b, '%Y-%m-%d %H:%M:%S.%f'))

        args = {'readings': values, 'date_time': dates}

            #print(dates)

        db.commit()
        db.close()

        return render(request,'HEMS/home.html', args)
